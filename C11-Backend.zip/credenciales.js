const credential = {
  "type": "service_account",
  "project_id": "devsafio-us",
  "private_key_id": "03ee196ef35fd2e807084898924eb42c6d63bd5c",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDQ/l1/A+nW53UR\nFoBsm7aCspiemOXLxeBeOQ2VB0MnvhpZaSoR4fMhH4TlnH2uwZMPNfnoqcM9XI+V\nZ4c4yXmW2WenAdMaUV31/JFrvAR2wM2020RpY1pQXRnQ/AJ7S7R1UUDuJbT1at3F\nbbh9P8q17eyhwORjmG9mGa4uCFChAVmMXBFWXHZJiJaxRsbkW3liq4LuPZaIpf9U\nirM8YDTM1ECTsgZBMZ+9hdjQu+cdP2FBE2ulSDvn7QXtiTSh1xrUnoiBjHwUBzoP\nb5ZUwaPOXJKhXPQPkf4dHIiOXR9eFObqw5LAjJntGhJnB0EJjp7BvysnTDZcEh1o\nuQ26BmWNAgMBAAECggEABRd4C6olaPjxSd30ebDpfLxWf4wAvTra69tpUKIr/qyL\nqSCox7rA2PkS8c0i5WkN6NGgfwyebGue4T2edmxiK/dWpnj4PayRz3ZnIerOE7Pq\nzxHbKX4kKyUO20qTJ5HWma0bGdzipcAEGyqV02dZzEjkT6SKwT/A0bSlIQtO0Of+\nOe9wQDReLmwoCVlBeqhO73dHxS1rY760Z1CegRroigWc4wRY+7A4BqLeY97Q7g1C\nNL+W4wU6l0z2kEA7QJaZPgNtUeZSrIF5T9y0O5riJeJK1L7bKotzPIO8DdXxyewx\nfZvCigsRdSpTZKHA2YgBix4xwv556+PSza0e7XpFwQKBgQDzuv/RUf/uFN0fjJll\nvLAkRhDsNBLvrGcYiM+L+vQs3bkPLvnoKHqrtUW35AwWEZblO3nDrpVnkV7etlvg\noPnasZKQqQp/ASLmfSG/1+ueGd2JIZpn4mNnS7HwUvT8ONqBuFQSiuIwBszf8DNf\njjW0h6DQV27fSSevCyBMtDavFQKBgQDbg7SeIwvgJ+VTailzxIKQ5imfT9Ww1AAG\n3AcuP2DdWYsslt2+GqjjwT1KtOkx2uLpXlnm0t9ANiHlZAzOeVo7Oo/envOge0yS\nosMv54vhdBQIekB6NVBLXBwnUaPXfTNvRsH+57MLepeAqRh64Dh2SSAH45naYddL\nLB57jjk6mQKBgHFbqvmfCsqft4yh5wKTdNUaJWrGeXwxki2uC+HOEV0Arr6qGZ9p\nnExaXhe+IATvn1/0fpiNjX2C9j3dUPQzyqF1b3aKuJADZkkPL/A7K6H347qQ/3CL\nsbHsWdEttDXO94nXwnpxT+wIbadF34705HOXlSrxT2bYbnWSVi52ruxVAoGAW1Om\nV4x5Kl8u1895Q4LkV2iKtI9AdnsdL71m92TC5hSVBI4X3zm0Pl1tJKGzy1wnv7PT\nb2cYHtzmqUtA0L5IPhAVPyeecIwbxX4V+t44oinrE8PZA38e0tuVkv4yTjr2pTsp\nBuZa5VGxqoOvfZ+/nea6fs3AeszuB4ZpgDohsTECgYBMwkuCccP1+liG5Uhijngv\nbgLTPFNFZjiaJAbugaLGS28RqouN4x1cNcQ/7PNTqzv44vv6aM2+XTEUzFE8IJ/G\nELK+Mhjt405Msf3q5KgVZ42Epgo3UybABowzYwfUGxKSHZhbTsxYeTJv3okm3aXg\njOa+d1cNkNkhlxVhgb9CFg==\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-jcvd5@devsafio-us.iam.gserviceaccount.com",
  "client_id": "113487399292270516778",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-jcvd5%40devsafio-us.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
}
export default credential;

