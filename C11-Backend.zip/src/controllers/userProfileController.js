import sequelize from "../database/connection.js";
import initModels from "../models/init-models.js";

const models = initModels(sequelize);

const userProfileController = {
  createUserProfile: async (req, res) => {
    const user = await models.user.findOne({
      where: {
        id: req.id,
      },
    });
    console.log(
      "🚀 ~ file: userProfileController.js:13 ~ createUserProfile: ~ user:",
      user
    );

    if (user) {
      return user;
    }

    const newUserProfile = await models.user_profile.create({
      user_id: req.userId,
      gender: req.body.gender,
      url_curriculum_vitar: req.body.url_curriculum_vitar,
      url_repository: req.body.url_repository,
      url_linkedin: req.body.url_linkedin,
      phone: req.body.phone,
      years_of_experience: req.body.years_of_experience,
      proud_experience: req.body.proud_experience,
      relocation: req.body.relocation,
      salary_expectations: req.body.salary_expectations,
    });
  },
};

export default userProfileController;
