import admin from "firebase-admin";
import dotenv from "dotenv";
import sequelize from "../database/connection.js";
import initModels from "../models/init-models.js";

const models = initModels(sequelize);

dotenv.config(); // Cargar variables de entorno

const serviceAccount = {
  type: process.env.TYPE,
  project_id: process.env.PROJECT_ID,
  private_key_id: process.env.PRIVATE_KEY_ID,
  private_key: process.env.PRIVATE_KEY.replace(/\\n/g, "\n"),
  client_email: process.env.CLIENT_EMAIL,
  client_id: process.env.CLIENT_ID,
  auth_uri: process.env.AUTH_URI,
  token_uri: process.env.TOKEN_URI,
  auth_provider_x509_cert_url: process.env.AUTH_PROVIDER_X509_CERT_URL,
  client_x509_cert_url: process.env.CLIENT_X509_CERT_URL,
};

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const authMiddleware = async (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res
      .status(401)
      .json({ error: "No se proporcionó un token de autenticación" });
  }

  const idToken = authHeader.split(" ")[1];

  try {
    const decodedToken = await admin.auth().verifyIdToken(idToken);

    // Obtener el ID del usuario desde tu base de datos local utilizando el correo electrónico
    const userId = await getUserIdByEmail(decodedToken.email);
    if (!userId) {
      return res
        .status(404)
        .json({ error: "Usuario no encontrado en la base de datos local" });
    }

    req.userId = userId; // Asignar el ID del usuario al objeto de solicitud
    next();
  } catch (error) {
    console.error("Error de autenticación:", error);
    return res.status(403).json({ error: "Acceso no autorizado", error });
  }
};

// Función para obtener el ID del usuario desde tu base de datos local
async function getUserIdByEmail(email) {
  try {
    const user = await models.user.findOne({
      where: {
        email: email,
      },
    });
    return user ? user.id : null;
  } catch (error) {
    console.error("Error al obtener el ID del usuario:", error);
    return null;
  }
}

export default authMiddleware;
